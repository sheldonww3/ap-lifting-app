import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state_provider.dart';
import '../models/level.dart';
import '../models/crane.dart';

class LevelCompletionScreen extends StatefulWidget {
  final int levelId;
  final int score;
  final int selectedCraneId;

  const LevelCompletionScreen({
    super.key,
    required this.levelId,
    required this.score,
    required this.selectedCraneId,
  });

  @override
  State<LevelCompletionScreen> createState() => _LevelCompletionScreenState();
}

class _LevelCompletionScreenState extends State<LevelCompletionScreen> {
  bool _scoreSaved = false;
  bool _nextLevelUnlocked = false;
  int? _nextLevelId;
  
  @override
  void initState() {
    super.initState();
    _saveScore();
  }
  
  Future<void> _saveScore() async {
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    
    // Save the score
    await appState.completeLevel(widget.levelId, widget.score);
    
    // Check if a next level was unlocked
    final level = appState.getLevelById(widget.levelId);
    if (level != null) {
      final nextLevelId = level.id + 1;
      final nextLevel = appState.getLevelById(nextLevelId);
      
      if (nextLevel != null && !nextLevel.isLocked) {
        _nextLevelUnlocked = true;
        _nextLevelId = nextLevelId;
      }
    }
    
    if (mounted) {
      setState(() {
        _scoreSaved = true;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppStateProvider>(context);
    final level = appState.getLevelById(widget.levelId);
    final crane = appState.getCraneById(widget.selectedCraneId);
    
    if (level == null || crane == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Level Complete'),
        ),
        body: const Center(
          child: Text('Error: Level or crane not found'),
        ),
      );
    }
    
    // Calculate max score and percentage
    final maxScore = level.maxScore;
    final scorePercentage = (widget.score / maxScore * 100).round();
    
    // Determine result quality
    final bool isCraneSuitable = level.liftScenario.suitableCraneIds.contains(widget.selectedCraneId);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Level Complete'),
        automaticallyImplyLeading: false, // Remove back button
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Success animation placeholder
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle_outline,
                color: Colors.green,
                size: 100,
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Level name and score
            Text(
              'Level ${level.id}: ${level.name}',
              style: Theme.of(context).textTheme.headlineMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Completed!',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Colors.green[700],
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            
            const SizedBox(height: 24),
            
            // Score display
            _buildScoreCard(context, widget.score, maxScore, scorePercentage),
            
            const SizedBox(height: 24),
            
            // Feedback on crane selection
            _buildFeedbackCard(context, crane, isCraneSuitable),
            
            const SizedBox(height: 32),
            
            // Next level notification
            if (_nextLevelUnlocked && _nextLevelId != null) ...[
              _buildNextLevelCard(context, appState, _nextLevelId!),
              const SizedBox(height: 24),
            ],
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                        context, 
                        '/levels', 
                        (route) => route.isFirst,
                      );
                    },
                    icon: const Icon(Icons.list),
                    label: const Text('Level Selection'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                        context, 
                        '/', 
                        (route) => false,
                      );
                    },
                    icon: const Icon(Icons.home),
                    label: const Text('Home'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildScoreCard(BuildContext context, int score, int maxScore, int percentage) {
    String feedback;
    Color feedbackColor;
    
    if (percentage >= 85) {
      feedback = 'Excellent!';
      feedbackColor = Colors.green;
    } else if (percentage >= 70) {
      feedback = 'Good job!';
      feedbackColor = Colors.blue;
    } else if (percentage >= 50) {
      feedback = 'Well done!';
      feedbackColor = Colors.orange;
    } else {
      feedback = 'Keep practicing!';
      feedbackColor = Colors.red;
    }
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              'Your Score',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  score.toString(),
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                    color: Theme.of(context).primaryColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  ' / $maxScore',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.grey[700],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '$percentage%',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: feedbackColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              feedback,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: feedbackColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildFeedbackCard(BuildContext context, Crane crane, bool isSuitable) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Crane Selection',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: crane.imageAsset.isNotEmpty
                      ? Image.asset(
                          crane.imageAsset,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(
                              Icons.construction,
                              size: 30,
                              color: Colors.grey[700],
                            );
                          },
                        )
                      : Icon(
                          Icons.construction,
                          size: 30,
                          color: Colors.grey[700],
                        ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        crane.name,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      Text(
                        _getCraneTypeLabel(crane.type),
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isSuitable ? Colors.green[50] : Colors.amber[50],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isSuitable ? 'Good Choice!' : 'Consider a Different Crane',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: isSuitable ? Colors.green[700] : Colors.amber[900],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isSuitable
                        ? 'This crane is appropriate for the specified lift parameters.'
                        : 'This crane may not be optimal for the lift parameters. Review crane specifications and lift requirements.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isSuitable ? Colors.green[900] : Colors.amber[900],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNextLevelCard(BuildContext context, AppStateProvider appState, int nextLevelId) {
    final nextLevel = appState.getLevelById(nextLevelId);
    
    if (nextLevel == null) {
      return const SizedBox.shrink();
    }
    
    return Card(
      elevation: 2,
      color: Theme.of(context).colorScheme.primaryContainer,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Icon(
                  Icons.unlock,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  size: 30,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'New Level Unlocked!',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Level ${nextLevel.id}: ${nextLevel.name}',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/level_detail',
                  (route) => route.isFirst,
                  arguments: nextLevelId,
                );
              },
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start Next Level'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
                foregroundColor: Theme.of(context).colorScheme.primaryContainer,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  String _getCraneTypeLabel(String type) {
    switch (type) {
      case 'mobile':
        return 'Mobile Crane';
      case 'tower':
        return 'Tower Crane';
      case 'luffer':
        return 'Luffing Crane';
      default:
        return type.toUpperCase();
    }
  }
}