import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state_provider.dart';
import '../models/level.dart';
import '../models/lift_scenario.dart';

class LevelDetailScreen extends StatelessWidget {
  const LevelDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the level ID from route arguments
    final levelId = ModalRoute.of(context)?.settings.arguments as int?;
    
    if (levelId == null) {
      // Handle case when no level ID is provided
      return Scaffold(
        appBar: AppBar(
          title: const Text('Level Details'),
        ),
        body: const Center(
          child: Text('Error: No level specified'),
        ),
      );
    }
    
    // Get the app state and level
    final appState = Provider.of<AppStateProvider>(context);
    final level = appState.getLevelById(levelId);
    
    if (level == null) {
      // Handle case when level isn't found
      return Scaffold(
        appBar: AppBar(
          title: const Text('Level Details'),
        ),
        body: Center(
          child: Text('Error: Level $levelId not found'),
        ),
      );
    }
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Level ${level.id}: ${level.name}'),
      ),
      body: _buildLevelDetail(context, level),
    );
  }
  
  Widget _buildLevelDetail(BuildContext context, Level level) {
    final scenario = level.liftScenario;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Level image
          Container(
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey[300],
            ),
            clipBehavior: Clip.antiAlias,
            child: level.imageAsset.isNotEmpty
                ? Image.asset(
                    level.imageAsset,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Center(
                        child: Icon(
                          Icons.engineering,
                          size: 80,
                          color: Colors.grey,
                        ),
                      );
                    },
                  )
                : const Center(
                    child: Icon(
                      Icons.engineering,
                      size: 80,
                      color: Colors.grey,
                    ),
                  ),
          ),
          
          const SizedBox(height: 20),
          
          // Level description
          Text(
            level.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 16),
          
          // Scenario title
          Text(
            'Lift Scenario: ${scenario.name}',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          
          const SizedBox(height: 16),
          
          // Scenario description
          Text(
            scenario.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          
          const SizedBox(height: 24),
          
          // Lift parameters
          _buildParametersCard(context, scenario),
          
          const SizedBox(height: 16),
          
          // Safety requirements
          _buildSafetyRequirementsCard(context, scenario),
          
          const SizedBox(height: 24),
          
          // Start level button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                _navigateToCraneSelection(context, level.id);
              },
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start Level'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          
          const SizedBox(height: 40),
        ],
      ),
    );
  }
  
  Widget _buildParametersCard(BuildContext context, LiftScenario scenario) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Lift Parameters',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            
            _buildParameterRow(
              context,
              'Load Weight',
              '${scenario.loadWeight} tonnes',
              Icons.fitness_center,
            ),
            
            const Divider(),
            
            _buildParameterRow(
              context,
              'Lift Radius',
              '${scenario.liftRadius} meters',
              Icons.radio_button_unchecked,
            ),
            
            const Divider(),
            
            _buildParameterRow(
              context,
              'Ground Condition',
              scenario.groundCondition.toUpperCase(),
              Icons.terrain,
            ),
            
            if (scenario.isConfinedSpace || scenario.isTandemLift || scenario.isNightLift) ...[
              const Divider(),
              const SizedBox(height: 8),
              
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (scenario.isConfinedSpace)
                    _buildSpecialConditionChip(
                      context,
                      'Confined Space',
                      Icons.crop_square,
                    ),
                  
                  if (scenario.isTandemLift)
                    _buildSpecialConditionChip(
                      context,
                      'Tandem Lift',
                      Icons.sync_alt,
                    ),
                  
                  if (scenario.isNightLift)
                    _buildSpecialConditionChip(
                      context,
                      'Night Operation',
                      Icons.nightlight_round,
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  Widget _buildParameterRow(BuildContext context, String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 24,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  value,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSpecialConditionChip(BuildContext context, String label, IconData icon) {
    return Chip(
      backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
      avatar: Icon(
        icon,
        color: Theme.of(context).primaryColor,
        size: 18,
      ),
      label: Text(
        label,
        style: TextStyle(
          color: Theme.of(context).primaryColor,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  Widget _buildSafetyRequirementsCard(BuildContext context, LiftScenario scenario) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.safety_divider,
                  color: Theme.of(context).primaryColor,
                ),
                const SizedBox(width: 8),
                Text(
                  'Safety Requirements',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ],
            ),
            const SizedBox(height: 16),
            
            ...scenario.safetyRequirements.map((requirement) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.check_circle_outline,
                      color: Colors.green[700],
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        requirement,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
  
  void _navigateToCraneSelection(BuildContext context, int levelId) {
    Navigator.pushNamed(
      context,
      '/crane_selection',
      arguments: levelId,
    );
  }
}