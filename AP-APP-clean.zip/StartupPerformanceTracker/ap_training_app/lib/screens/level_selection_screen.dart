import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state_provider.dart';
import '../models/level.dart';

class LevelSelectionScreen extends StatelessWidget {
  const LevelSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the app state
    final appState = Provider.of<AppStateProvider>(context);
    final levels = appState.levels;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Level'),
      ),
      body: appState.isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildLevelGrid(context, levels),
    );
  }
  
  Widget _buildLevelGrid(BuildContext context, List<Level> levels) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.8,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: levels.length,
      itemBuilder: (context, index) {
        final level = levels[index];
        return _buildLevelCard(context, level);
      },
    );
  }
  
  Widget _buildLevelCard(BuildContext context, Level level) {
    // Access app state for user progress
    final appState = Provider.of<AppStateProvider>(context);
    final userProgress = appState.userProgress;
    
    // Check if level is completed
    final isCompleted = userProgress.isLevelCompleted(level.id);
    final score = userProgress.getLevelScore(level.id);
    
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: level.isLocked 
            ? () => _showLockedLevelDialog(context, level) 
            : () => _navigateToLevelDetail(context, level),
        child: Stack(
          children: [
            // Level image or placeholder
            Positioned.fill(
              child: Container(
                color: Colors.grey[300],
                child: level.imageAsset.isNotEmpty
                    ? Image.asset(
                        level.imageAsset,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Center(
                            child: Icon(
                              Icons.engineering,
                              size: 60,
                              color: Colors.grey[700],
                            ),
                          );
                        },
                      )
                    : Center(
                        child: Icon(
                          Icons.engineering,
                          size: 60,
                          color: Colors.grey[700],
                        ),
                      ),
              ),
            ),
            
            // Overlay for locked levels
            if (level.isLocked)
              Positioned.fill(
                child: Container(
                  color: Colors.black.withOpacity(0.6),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.lock,
                          color: Colors.white,
                          size: 40,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Score ${level.requiredScore} to unlock',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            
            // Level info at bottom
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                color: Colors.black.withOpacity(0.7),
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Level ${level.id}: ${level.name}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (isCompleted) ...[
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Completed: $score points',
                            style: TextStyle(
                              color: Colors.green[100],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            
            // Rank badge
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.amber[700],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  level.rank,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void _showLockedLevelDialog(BuildContext context, Level level) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Level Locked'),
          content: Text(
            'You need to score at least ${level.requiredScore} points in previous levels to unlock this level.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
  
  void _navigateToLevelDetail(BuildContext context, Level level) {
    Navigator.pushNamed(
      context,
      '/level_detail',
      arguments: level.id,
    );
  }
}