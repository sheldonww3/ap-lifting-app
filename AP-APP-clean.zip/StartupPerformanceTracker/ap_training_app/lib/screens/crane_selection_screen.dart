import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state_provider.dart';
import '../models/crane.dart';
import '../models/level.dart';
import 'level_completion_screen.dart';

class CraneSelectionScreen extends StatefulWidget {
  const CraneSelectionScreen({super.key});

  @override
  State<CraneSelectionScreen> createState() => _CraneSelectionScreenState();
}

class _CraneSelectionScreenState extends State<CraneSelectionScreen> {
  int? selectedCraneId;
  List<String> selectedSafetyMeasures = [];
  
  @override
  Widget build(BuildContext context) {
    // Get the level ID from route arguments
    final levelId = ModalRoute.of(context)?.settings.arguments as int?;
    
    if (levelId == null) {
      // Handle case when no level ID is provided
      return Scaffold(
        appBar: AppBar(
          title: const Text('Select Crane'),
        ),
        body: const Center(
          child: Text('Error: No level specified'),
        ),
      );
    }
    
    // Get the app state and level
    final appState = Provider.of<AppStateProvider>(context);
    final level = appState.getLevelById(levelId);
    
    if (level == null) {
      // Handle case when level isn't found
      return Scaffold(
        appBar: AppBar(
          title: const Text('Select Crane'),
        ),
        body: Center(
          child: Text('Error: Level $levelId not found'),
        ),
      );
    }
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Level ${level.id}: Select Crane'),
      ),
      body: _buildCraneSelectionContent(context, appState, level),
    );
  }
  
  Widget _buildCraneSelectionContent(BuildContext context, AppStateProvider appState, Level level) {
    final cranes = appState.cranes;
    final scenario = level.liftScenario;
    
    return Column(
      children: [
        // Task header
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          color: Theme.of(context).primaryColor.withOpacity(0.1),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select the best crane for this lift:',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                '${scenario.loadWeight} tonnes at ${scenario.liftRadius} meters on ${scenario.groundCondition} ground',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              if (scenario.isConfinedSpace || scenario.isTandemLift || scenario.isNightLift) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    if (scenario.isConfinedSpace)
                      _buildConditionChip('Confined Space'),
                    if (scenario.isTandemLift)
                      _buildConditionChip('Tandem Lift'),
                    if (scenario.isNightLift)
                      _buildConditionChip('Night Operation'),
                  ],
                ),
              ],
            ],
          ),
        ),
        
        // Crane list
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: cranes.length,
            itemBuilder: (context, index) {
              final crane = cranes[index];
              return _buildCraneCard(context, crane, level);
            },
          ),
        ),
        
        // Submit button
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: selectedCraneId == null
                  ? null
                  : () => _submitSelection(context, appState, level),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  selectedCraneId == null
                      ? 'Select a Crane to Continue'
                      : 'Confirm Selection',
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildConditionChip(String label) {
    return Chip(
      backgroundColor: Colors.orange.withOpacity(0.2),
      label: Text(
        label,
        style: const TextStyle(
          color: Colors.deepOrange,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  Widget _buildCraneCard(BuildContext context, Crane crane, Level level) {
    final isSelected = selectedCraneId == crane.id;
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    final isSuitable = appState.isCraneSuitableForScenario(crane, level);
    
    return Card(
      elevation: isSelected ? 4 : 2,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isSelected 
              ? Theme.of(context).primaryColor 
              : Colors.transparent,
          width: 2,
        ),
      ),
      child: InkWell(
        onTap: () {
          setState(() {
            selectedCraneId = crane.id;
          });
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Crane header row
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: crane.imageAsset.isNotEmpty
                        ? Image.asset(
                            crane.imageAsset,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                Icons.construction,
                                size: 30,
                                color: Colors.grey[700],
                              );
                            },
                          )
                        : Icon(
                            Icons.construction,
                            size: 30,
                            color: Colors.grey[700],
                          ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          crane.name,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        Text(
                          _getCraneTypeLabel(crane.type),
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[700],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isSelected)
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                ],
              ),
              
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              
              // Crane specifications
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildSpecColumn(
                    context, 
                    'Capacity', 
                    '${crane.maxCapacity} tonnes',
                  ),
                  _buildSpecColumn(
                    context, 
                    'Max Radius', 
                    '${crane.maxRadius} m',
                  ),
                  _buildSpecColumn(
                    context, 
                    'Setup Time', 
                    '${crane.setupTime} hrs',
                  ),
                ],
              ),
              
              const SizedBox(height: 16),
              
              // Ground conditions
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: crane.suitableGroundConditions.map((condition) {
                  return Chip(
                    backgroundColor: Colors.green[50],
                    label: Text(
                      condition.toUpperCase(),
                      style: TextStyle(
                        color: Colors.green[700],
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                }).toList(),
              ),
              
              const SizedBox(height: 8),
              
              // Special features
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (crane.canOperateAtNight)
                    _buildFeatureChip(context, 'Night Operation'),
                  if (crane.supportsConfinedSpaces)
                    _buildFeatureChip(context, 'Confined Spaces'),
                  if (crane.supportsTandemLifts)
                    _buildFeatureChip(context, 'Tandem Lifts'),
                ],
              ),
              
              // Suitable indicator
              if (isSelected) ...[
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: isSuitable ? Colors.green[50] : Colors.red[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isSuitable ? Icons.check_circle : Icons.warning,
                        color: isSuitable ? Colors.green : Colors.red,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isSuitable 
                            ? 'This crane is suitable for the lift' 
                            : 'This crane may not be suitable',
                        style: TextStyle(
                          color: isSuitable ? Colors.green[800] : Colors.red[800],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
  
  String _getCraneTypeLabel(String type) {
    switch (type) {
      case 'mobile':
        return 'Mobile Crane';
      case 'tower':
        return 'Tower Crane';
      case 'luffer':
        return 'Luffing Crane';
      default:
        return type.toUpperCase();
    }
  }
  
  Widget _buildSpecColumn(BuildContext context, String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
  
  Widget _buildFeatureChip(BuildContext context, String label) {
    return Chip(
      backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
      label: Text(
        label,
        style: TextStyle(
          color: Theme.of(context).primaryColor,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  void _submitSelection(BuildContext context, AppStateProvider appState, Level level) {
    if (selectedCraneId == null) return;
    
    // Show safety measures selection dialog
    _showSafetyMeasuresDialog(context, appState, level);
  }

  void _showSafetyMeasuresDialog(BuildContext context, AppStateProvider appState, Level level) {
    // Create a temporary list for dialog selections
    List<String> tempSelectedMeasures = List.from(selectedSafetyMeasures);
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Select Safety Measures'),
              content: SizedBox(
                width: double.maxFinite,
                child: ListView(
                  shrinkWrap: true,
                  children: level.liftScenario.safetyRequirements.map((measure) {
                    return CheckboxListTile(
                      title: Text(measure),
                      value: tempSelectedMeasures.contains(measure),
                      onChanged: (bool? value) {
                        setState(() {
                          if (value == true) {
                            tempSelectedMeasures.add(measure);
                          } else {
                            tempSelectedMeasures.remove(measure);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Update selected safety measures
                    setState(() {
                      selectedSafetyMeasures = tempSelectedMeasures;
                    });
                    
                    // Calculate the score
                    int score = appState.calculateScore(
                      level, 
                      selectedCraneId!, 
                      selectedSafetyMeasures,
                    );
                    
                    // Close dialog
                    Navigator.of(context).pop();
                    
                    // Navigate to completion screen
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LevelCompletionScreen(
                          levelId: level.id,
                          score: score,
                          selectedCraneId: selectedCraneId!,
                        ),
                      ),
                    );
                  },
                  child: const Text('Confirm'),
                ),
              ],
            );
          }
        );
      },
    );
  }
}