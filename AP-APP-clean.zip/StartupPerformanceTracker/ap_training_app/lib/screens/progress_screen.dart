import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state_provider.dart';
import '../models/level.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppStateProvider>(context);
    final userProgress = appState.userProgress;
    final levels = appState.levels;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Progress'),
      ),
      body: appState.isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // User rank card
                  _buildRankCard(context, userProgress.currentRank, userProgress.totalScore),
                  
                  const SizedBox(height: 24),
                  
                  // Level progress
                  Text(
                    'Level Progress',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 16),
                  
                  // Progress bar
                  _buildProgressBar(context, userProgress.completedLevelIds.length, levels.length),
                  
                  const SizedBox(height: 24),
                  
                  // Level scores
                  Text(
                    'Level Scores',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 16),
                  
                  // Level scores list
                  ...levels.map((level) => _buildLevelScoreItem(context, level, userProgress.getLevelScore(level.id))),
                  
                  const SizedBox(height: 24),
                  
                  // Reset progress button
                  Center(
                    child: OutlinedButton.icon(
                      onPressed: () => _showResetConfirmation(context, appState),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Reset Progress'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red,
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                ],
              ),
            ),
    );
  }
  
  Widget _buildRankCard(BuildContext context, String rank, int totalScore) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Rank icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.emoji_events,
                color: Theme.of(context).primaryColor,
                size: 50,
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Rank name
            Text(
              'Current Rank',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              rank,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            
            // Total score
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                const SizedBox(width: 8),
                Text(
                  'Total Score: $totalScore',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            // Next rank indicator
            const SizedBox(height: 16),
            _buildNextRankIndicator(context, rank, totalScore),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNextRankIndicator(BuildContext context, String currentRank, int totalScore) {
    // Define rank thresholds and titles
    final Map<String, Map<String, dynamic>> rankInfo = {
      'Labourer': {
        'next': 'Rigger',
        'threshold': 100,
      },
      'Rigger': {
        'next': 'Banksman',
        'threshold': 200,
      },
      'Banksman': {
        'next': 'Slinger Signaller',
        'threshold': 300,
      },
      'Slinger Signaller': {
        'next': 'Lift Supervisor',
        'threshold': 400,
      },
      'Lift Supervisor': {
        'next': 'Appointed Person',
        'threshold': 500,
      },
      'Appointed Person': {
        'next': null,
        'threshold': null,
      },
    };
    
    if (!rankInfo.containsKey(currentRank)) {
      return const SizedBox.shrink();
    }
    
    final nextRank = rankInfo[currentRank]?['next'];
    final threshold = rankInfo[currentRank]?['threshold'];
    
    if (nextRank == null || threshold == null) {
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.green[50],
          borderRadius: BorderRadius.circular(8),
        ),
        child: const Text(
          'Maximum Rank Achieved!',
          style: TextStyle(
            color: Colors.green,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    }
    
    // Calculate progress to next rank
    final previousRankThreshold = rankInfo.entries
        .firstWhere((entry) => entry.value['next'] == currentRank, 
                    orElse: () => const MapEntry('', {'threshold': 0}))
        .value['threshold'] as int;
    
    final progress = (totalScore - previousRankThreshold) / (threshold - previousRankThreshold);
    final clampedProgress = progress.clamp(0.0, 1.0);
    
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Next Rank: $nextRank',
              style: TextStyle(
                color: Colors.grey[700],
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '$totalScore / $threshold',
              style: TextStyle(
                color: Colors.grey[700],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        LinearProgressIndicator(
          value: clampedProgress,
          backgroundColor: Colors.grey[300],
          minHeight: 8,
          borderRadius: BorderRadius.circular(4),
        ),
      ],
    );
  }
  
  Widget _buildProgressBar(BuildContext context, int completedLevels, int totalLevels) {
    final progress = completedLevels / totalLevels;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Levels Completed',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  '$completedLevels / $totalLevels',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: progress,
              minHeight: 10,
              backgroundColor: Colors.grey[300],
              borderRadius: BorderRadius.circular(5),
            ),
            const SizedBox(height: 8),
            Text(
              '${(progress * 100).round()}% Complete',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildLevelScoreItem(BuildContext context, Level level, int score) {
    final bool isLevelCompleted = score > 0;
    final double progressValue = isLevelCompleted ? score / level.maxScore : 0.0;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // Level number circle
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: level.isLocked
                    ? Colors.grey[300]
                    : Theme.of(context).primaryColor,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  level.id.toString(),
                  style: TextStyle(
                    color: level.isLocked ? Colors.grey[700] : Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            
            const SizedBox(width: 16),
            
            // Level info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    level.name,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      decoration: level.isLocked ? TextDecoration.lineThrough : null,
                      color: level.isLocked ? Colors.grey[700] : null,
                    ),
                  ),
                  const SizedBox(height: 4),
                  LinearProgressIndicator(
                    value: progressValue,
                    backgroundColor: Colors.grey[300],
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ],
              ),
            ),
            
            const SizedBox(width: 16),
            
            // Score
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: isLevelCompleted
                    ? Theme.of(context).primaryColor
                    : Colors.grey[300],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                isLevelCompleted ? '$score pts' : 'Not Started',
                style: TextStyle(
                  color: isLevelCompleted ? Colors.white : Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void _showResetConfirmation(BuildContext context, AppStateProvider appState) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset Progress?'),
          content: const Text(
            'This will reset all your progress, scores, and unlocked levels. This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                await appState.resetProgress();
                if (context.mounted) {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Progress has been reset'),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );
  }
}