// Sample data utility for providing initial app data
import '../models/crane.dart';
import '../models/level.dart';
import '../models/lift_scenario.dart';

class SampleData {
  // Get a list of sample cranes
  static List<Crane> getCranes() {
    return [
      // Mobile Cranes
      Crane(
        id: 1,
        name: 'LTM 1060-3.1',
        type: 'mobile',
        maxCapacity: 60.0, // tonnes
        maxRadius: 40.0, // meters
        minRadius: 3.0, // meters
        imageAsset: 'assets/images/mobile_crane_1.png',
        loadChart: {
          3.0: 60.0,
          5.0: 40.0,
          10.0: 20.0,
          15.0: 13.0,
          20.0: 9.5,
          25.0: 7.0,
          30.0: 5.5,
          35.0: 4.0,
          40.0: 3.0,
        },
        setupTime: 1.0, // hours
        suitableGroundConditions: ['firm', 'compacted'],
        canOperateAtNight: true,
        supportsConfinedSpaces: false,
        supportsTandemLifts: false,
      ),
      Crane(
        id: 2,
        name: 'LTM 1090-4.2',
        type: 'mobile',
        maxCapacity: 90.0,
        maxRadius: 50.0,
        minRadius: 3.0,
        imageAsset: 'assets/images/mobile_crane_2.png',
        loadChart: {
          3.0: 90.0,
          5.0: 70.0,
          10.0: 35.0,
          15.0: 22.0,
          20.0: 16.0,
          25.0: 12.0,
          30.0: 9.0,
          35.0: 7.0,
          40.0: 5.5,
          45.0: 4.2,
          50.0: 3.5,
        },
        setupTime: 1.5,
        suitableGroundConditions: ['firm', 'compacted', 'uneven'],
        canOperateAtNight: true,
        supportsConfinedSpaces: true,
        supportsTandemLifts: true,
      ),
      
      // Tower Cranes
      Crane(
        id: 3,
        name: 'CTT 161A-8',
        type: 'tower',
        maxCapacity: 8.0,
        maxRadius: 65.0,
        minRadius: 2.5,
        imageAsset: 'assets/images/tower_crane_1.png',
        loadChart: {
          2.5: 8.0,
          10.0: 8.0,
          20.0: 7.5,
          30.0: 5.0,
          40.0: 3.8,
          50.0: 3.0,
          60.0: 2.2,
          65.0: 1.8,
        },
        setupTime: 8.0, // requires more time to set up
        suitableGroundConditions: ['firm', 'compacted'],
        canOperateAtNight: true,
        supportsConfinedSpaces: true,
        supportsTandemLifts: false,
      ),
      
      // Luffing Cranes
      Crane(
        id: 4,
        name: 'LR 1300 SX',
        type: 'luffer',
        maxCapacity: 300.0,
        maxRadius: 82.0,
        minRadius: 5.0,
        imageAsset: 'assets/images/luffing_crane_1.png',
        loadChart: {
          5.0: 300.0,
          10.0: 180.0,
          20.0: 92.0,
          30.0: 60.0,
          40.0: 42.0,
          50.0: 32.0,
          60.0: 26.0,
          70.0: 19.0,
          80.0: 14.0,
          82.0: 13.5,
        },
        setupTime: 6.0,
        suitableGroundConditions: ['firm', 'compacted', 'uneven'],
        canOperateAtNight: true,
        supportsConfinedSpaces: true,
        supportsTandemLifts: true,
      ),
      Crane(
        id: 5,
        name: 'CTL 260-18',
        type: 'luffer',
        maxCapacity: 18.0,
        maxRadius: 60.0,
        minRadius: 4.0,
        imageAsset: 'assets/images/luffing_crane_2.png',
        loadChart: {
          4.0: 18.0,
          10.0: 16.5,
          20.0: 10.2,
          30.0: 6.8,
          40.0: 5.0,
          50.0: 3.5,
          60.0: 2.5,
        },
        setupTime: 4.0,
        suitableGroundConditions: ['firm', 'compacted'],
        canOperateAtNight: true,
        supportsConfinedSpaces: true,
        supportsTandemLifts: false,
      ),
    ];
  }

  // Get a list of sample levels
  static List<Level> getLevels() {
    return [
      // Level 1 - Basic Lift
      Level(
        id: 1,
        name: 'Basic Lift',
        description: 'A simple lifting operation on a firm, open site with good visibility.',
        requiredScore: 0, // First level, no requirements
        liftScenario: LiftScenario(
          id: 1,
          name: 'Simple Lift',
          description: 'Lift a 5-tonne load at a radius of 15 meters on firm ground.',
          loadWeight: 5.0,
          liftRadius: 15.0,
          groundCondition: 'firm',
          isConfinedSpace: false,
          isTandemLift: false,
          isNightLift: false,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
          ],
          suitableCraneIds: [1, 2, 4],
          siteLayoutImage: 'assets/images/level1_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.2,
              'y': 0.3,
              'width': 0.3,
              'height': 0.3,
            },
          ],
        ),
        rank: 'Labourer',
        maxScore: 100,
        isLocked: false, // First level is unlocked by default
        imageAsset: 'assets/images/level1.png',
      ),
      
      // Level 2 - Uneven Ground Lift
      Level(
        id: 2,
        name: 'Uneven Ground',
        description: 'Lifting on uneven ground requires careful crane selection and setup.',
        requiredScore: 70, // Need 70 points from Level 1
        liftScenario: LiftScenario(
          id: 2,
          name: 'Uneven Ground Lift',
          description: 'Lift a 10-tonne load at a radius of 20 meters on uneven ground.',
          loadWeight: 10.0,
          liftRadius: 20.0,
          groundCondition: 'uneven',
          isConfinedSpace: false,
          isTandemLift: false,
          isNightLift: false,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
            'Ground Assessment',
            'Extended Outriggers',
          ],
          suitableCraneIds: [2, 4],
          siteLayoutImage: 'assets/images/level2_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.2,
              'y': 0.3,
              'width': 0.4,
              'height': 0.4,
            },
            {
              'name': 'Secondary Zone',
              'x': 0.6,
              'y': 0.1,
              'width': 0.2,
              'height': 0.2,
            },
          ],
        ),
        rank: 'Rigger',
        maxScore: 120,
        isLocked: true,
        imageAsset: 'assets/images/level2.png',
      ),
      
      // Level 3 - Confined Space
      Level(
        id: 3,
        name: 'Confined Space',
        description: 'Operating in a confined space with limited swing radius.',
        requiredScore: 160, // Cumulative score from previous levels
        liftScenario: LiftScenario(
          id: 3,
          name: 'Confined Site Lift',
          description: 'Lift a 7-tonne load at a radius of 30 meters in a confined space with buildings nearby.',
          loadWeight: 7.0,
          liftRadius: 30.0,
          groundCondition: 'compacted',
          isConfinedSpace: true,
          isTandemLift: false,
          isNightLift: false,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
            'Movement Limiters',
            'Site Survey',
            'Traffic Management',
          ],
          suitableCraneIds: [2, 3, 4, 5],
          siteLayoutImage: 'assets/images/level3_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.1,
              'y': 0.3,
              'width': 0.4,
              'height': 0.3,
            },
            {
              'name': 'Building Protection Zone',
              'x': 0.6,
              'y': 0.1,
              'width': 0.3,
              'height': 0.5,
            },
            {
              'name': 'Access Route',
              'x': 0.1,
              'y': 0.7,
              'width': 0.7,
              'height': 0.2,
            },
          ],
        ),
        rank: 'Banksman',
        maxScore: 150,
        isLocked: true,
        imageAsset: 'assets/images/level3.png',
      ),
      
      // Level 4 - Night Lift
      Level(
        id: 4,
        name: 'Night Operation',
        description: 'Conducting a lifting operation at night with limited visibility.',
        requiredScore: 250,
        liftScenario: LiftScenario(
          id: 4,
          name: 'Night Lift',
          description: 'Lift a 12-tonne load at a radius of 25 meters at night.',
          loadWeight: 12.0,
          liftRadius: 25.0,
          groundCondition: 'firm',
          isConfinedSpace: false,
          isTandemLift: false,
          isNightLift: true,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
            'Lighting Towers',
            'Reflective Clothing',
            'Radio Communication',
            'Pre-shift Briefing',
          ],
          suitableCraneIds: [2, 3, 4, 5],
          siteLayoutImage: 'assets/images/level4_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.2,
              'y': 0.2,
              'width': 0.5,
              'height': 0.5,
            },
            {
              'name': 'Lighting Tower Zone',
              'x': 0.7,
              'y': 0.3,
              'width': 0.2,
              'height': 0.2,
            },
          ],
        ),
        rank: 'Slinger Signaller',
        maxScore: 180,
        isLocked: true,
        imageAsset: 'assets/images/level4.png',
      ),
      
      // Level 5 - Tandem Lift
      Level(
        id: 5,
        name: 'Tandem Lift',
        description: 'Operating a tandem lift with two cranes working together.',
        requiredScore: 350,
        liftScenario: LiftScenario(
          id: 5,
          name: 'Tandem Lift',
          description: 'Lift a 30-tonne long load using two cranes in tandem.',
          loadWeight: 15.0, // Per crane
          liftRadius: 20.0,
          groundCondition: 'compacted',
          isConfinedSpace: false,
          isTandemLift: true,
          isNightLift: false,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
            'Lift Supervisor',
            'Synchronized Communications',
            'Load Stability Assessment',
            'Wind Speed Monitoring',
            'Detailed Lift Plan',
          ],
          suitableCraneIds: [2, 4],
          siteLayoutImage: 'assets/images/level5_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.1,
              'y': 0.2,
              'width': 0.7,
              'height': 0.5,
            },
            {
              'name': 'Supervisor Station',
              'x': 0.8,
              'y': 0.3,
              'width': 0.1,
              'height': 0.1,
            },
            {
              'name': 'Emergency Access',
              'x': 0.1,
              'y': 0.8,
              'width': 0.8,
              'height': 0.1,
            },
          ],
        ),
        rank: 'Lift Supervisor',
        maxScore: 220,
        isLocked: true,
        imageAsset: 'assets/images/level5.png',
      ),
      
      // Level 6 - Complex Lift
      Level(
        id: 6,
        name: 'Complex Site',
        description: 'A complex lifting operation combining multiple challenges.',
        requiredScore: 450,
        liftScenario: LiftScenario(
          id: 6,
          name: 'Complex Lift',
          description: 'Lift a 20-tonne load at night in a confined space with uneven ground.',
          loadWeight: 20.0,
          liftRadius: 30.0,
          groundCondition: 'uneven',
          isConfinedSpace: true,
          isTandemLift: false,
          isNightLift: true,
          safetyRequirements: [
            'Banksman',
            'Hard Hats',
            'Exclusion Zone',
            'Lighting Towers',
            'Reflective Clothing',
            'Radio Communication',
            'Ground Assessment',
            'Extended Outriggers',
            'Movement Limiters',
            'Site Survey',
            'Traffic Management',
            'Wind Speed Monitoring',
            'Detailed Lift Plan',
          ],
          suitableCraneIds: [4],
          siteLayoutImage: 'assets/images/level6_site.png',
          exclusionZones: [
            {
              'name': 'Primary Exclusion Zone',
              'x': 0.1,
              'y': 0.1,
              'width': 0.6,
              'height': 0.6,
            },
            {
              'name': 'Building Protection',
              'x': 0.7,
              'y': 0.1,
              'width': 0.2,
              'height': 0.4,
            },
            {
              'name': 'Lighting Tower Zone',
              'x': 0.7,
              'y': 0.6,
              'width': 0.2,
              'height': 0.2,
            },
            {
              'name': 'Access Route',
              'x': 0.1,
              'y': 0.8,
              'width': 0.8,
              'height': 0.1,
            },
          ],
        ),
        rank: 'Appointed Person',
        maxScore: 250,
        isLocked: true,
        imageAsset: 'assets/images/level6.png',
      ),
    ];
  }
}