import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/app_state_provider.dart';
import 'screens/home_screen.dart';
import 'screens/level_selection_screen.dart';
import 'screens/level_detail_screen.dart';
import 'screens/crane_selection_screen.dart';
import 'screens/progress_screen.dart';

void main() {
  // Ensure Flutter is initialized
  WidgetsFlutterBinding.ensureInitialized();
  
  // Run the app with the provider at the root
  runApp(
    ChangeNotifierProvider(
      create: (context) => AppStateProvider(),
      child: const APTrainingApp(),
    ),
  );
}

class APTrainingApp extends StatelessWidget {
  const APTrainingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AP Training App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Use a modern Material 3 design
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1565C0), // Blue primary color
          brightness: Brightness.light,
        ),
        // Use the Material 3 design system
        useMaterial3: true,
        
        // Configure the app bar theme
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1565C0),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        
        // Configure button themes
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1565C0), 
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        
        // Configure text themes
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          displayMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          displaySmall: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          headlineMedium: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
          titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          bodyLarge: TextStyle(fontSize: 16),
          bodyMedium: TextStyle(fontSize: 14),
        ),
      ),
      
      // Define routes for navigation
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/levels': (context) => const LevelSelectionScreen(),
        '/level_detail': (context) => const LevelDetailScreen(),
        '/crane_selection': (context) => const CraneSelectionScreen(),
        '/progress': (context) => const ProgressScreen(),
      },
    );
  }
}
