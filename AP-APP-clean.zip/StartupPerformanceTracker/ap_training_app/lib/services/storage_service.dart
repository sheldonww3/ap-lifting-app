// Storage Service for handling local data persistence
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user_progress.dart';

class StorageService {
  // Keys for SharedPreferences
  static const String _userProgressKey = 'user_progress';
  
  // Save user progress to local storage
  Future<bool> saveUserProgress(UserProgress userProgress) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonData = userProgress.toJson();
      final jsonString = json.encode(jsonData);
      return await prefs.setString(_userProgressKey, jsonString);
    } catch (e) {
      print('Error saving user progress: $e');
      return false;
    }
  }
  
  // Load user progress from local storage
  Future<UserProgress> loadUserProgress() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonString = prefs.getString(_userProgressKey);
      
      if (jsonString == null) {
        // Return default user progress if none exists
        return UserProgress();
      }
      
      final jsonData = json.decode(jsonString);
      return UserProgress.fromJson(jsonData);
    } catch (e) {
      print('Error loading user progress: $e');
      // Return default user progress if error occurs
      return UserProgress();
    }
  }
  
  // Clear all user progress (reset)
  Future<bool> clearUserProgress() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return await prefs.remove(_userProgressKey);
    } catch (e) {
      print('Error clearing user progress: $e');
      return false;
    }
  }
}