// App State Provider for managing the app's state
import 'package:flutter/material.dart';

import '../models/crane.dart';
import '../models/level.dart';
import '../models/user_progress.dart';
import '../services/storage_service.dart';
import '../utils/sample_data.dart';

class AppStateProvider with ChangeNotifier {
  late UserProgress _userProgress;
  late List<Level> _levels;
  late List<Crane> _cranes;
  final StorageService _storageService = StorageService();
  bool _isLoading = true;

  // Getters
  UserProgress get userProgress => _userProgress;
  List<Level> get levels => _levels;
  List<Crane> get cranes => _cranes;
  bool get isLoading => _isLoading;

  // Constructor - initialize with empty data
  AppStateProvider() {
    _userProgress = UserProgress();
    _levels = [];
    _cranes = [];
    _initializeData();
  }

  // Initialize data - load from local storage or use defaults
  Future<void> _initializeData() async {
    _isLoading = true;
    notifyListeners();

    // Load user progress from storage
    _userProgress = await _storageService.loadUserProgress();
    
    // Load levels and cranes from sample data
    _levels = SampleData.getLevels();
    _cranes = SampleData.getCranes();
    
    // Update level lock status based on user progress
    _updateLevelLockStatus();
    
    _isLoading = false;
    notifyListeners();
  }

  // Update which levels are locked/unlocked based on user progress
  void _updateLevelLockStatus() {
    for (int i = 0; i < _levels.length; i++) {
      bool isLocked = _levels[i].id > _userProgress.highestUnlockedLevelId;
      _levels[i] = _levels[i].copyWith(isLocked: isLocked);
    }
  }

  // Complete a level and save progress
  Future<void> completeLevel(int levelId, int score) async {
    // Add the completed level to user progress
    _userProgress = _userProgress.addCompletedLevel(levelId, score);
    
    // Update rank based on new total score
    _userProgress = _userProgress.updateRank();
    
    // Update level lock status
    _updateLevelLockStatus();
    
    // Save progress to local storage
    await _storageService.saveUserProgress(_userProgress);
    
    notifyListeners();
  }

  // Reset all progress
  Future<void> resetProgress() async {
    // Create a new user progress with default values
    _userProgress = UserProgress();
    
    // Clear progress from storage
    await _storageService.clearUserProgress();
    
    // Update level lock status
    _updateLevelLockStatus();
    
    notifyListeners();
  }

  // Get a specific level by ID
  Level? getLevelById(int levelId) {
    try {
      return _levels.firstWhere((level) => level.id == levelId);
    } catch (e) {
      return null;
    }
  }

  // Get a specific crane by ID
  Crane? getCraneById(int craneId) {
    try {
      return _cranes.firstWhere((crane) => crane.id == craneId);
    } catch (e) {
      return null;
    }
  }
  
  // Check if a crane is suitable for a specific lift scenario
  bool isCraneSuitableForScenario(Crane crane, Level level) {
    var scenario = level.liftScenario;
    
    // Check weight and radius capability
    if (!crane.canHandleLift(scenario.loadWeight, scenario.liftRadius)) {
      return false;
    }
    
    // Check ground condition suitability
    if (!crane.isSuitableForGroundCondition(scenario.groundCondition)) {
      return false;
    }
    
    // Check special requirements
    if (scenario.isConfinedSpace && !crane.supportsConfinedSpaces) {
      return false;
    }
    
    if (scenario.isTandemLift && !crane.supportsTandemLifts) {
      return false;
    }
    
    if (scenario.isNightLift && !crane.canOperateAtNight) {
      return false;
    }
    
    return true;
  }
  
  // Calculate score for a level based on crane selection and other factors
  int calculateScore(Level level, int selectedCraneId, List<String> selectedSafetyMeasures) {
    int score = 0;
    int maxScore = level.maxScore;
    var scenario = level.liftScenario;
    
    // Score for correct crane selection (60% of total)
    if (scenario.suitableCraneIds.contains(selectedCraneId)) {
      score += (maxScore * 0.6).round();
    }
    
    // Score for safety measures (40% of total)
    int requiredSafetyMeasures = scenario.safetyRequirements.length;
    int correctSafetyMeasures = 0;
    
    for (var measure in selectedSafetyMeasures) {
      if (scenario.safetyRequirements.contains(measure)) {
        correctSafetyMeasures++;
      }
    }
    
    if (requiredSafetyMeasures > 0) {
      double safetyScore = (correctSafetyMeasures / requiredSafetyMeasures) * (maxScore * 0.4);
      score += safetyScore.round();
    }
    
    return score;
  }
}