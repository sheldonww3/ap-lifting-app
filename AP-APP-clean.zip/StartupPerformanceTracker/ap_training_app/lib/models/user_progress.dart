// User Progress model to track user's achievements and progress

class UserProgress {
  final int totalScore;
  final String currentRank;
  final List<int> completedLevelIds;
  final Map<int, int> levelScores; // Level ID to score mapping
  final int highestUnlockedLevelId;

  UserProgress({
    this.totalScore = 0,
    this.currentRank = 'Labourer', // Starting rank
    this.completedLevelIds = const [],
    this.levelScores = const {},
    this.highestUnlockedLevelId = 1, // First level is unlocked by default
  });

  // Check if a level is completed
  bool isLevelCompleted(int levelId) {
    return completedLevelIds.contains(levelId);
  }

  // Get score for a specific level
  int getLevelScore(int levelId) {
    return levelScores[levelId] ?? 0;
  }

  // Factory method to create user progress from JSON
  factory UserProgress.fromJson(Map<String, dynamic> json) {
    return UserProgress(
      totalScore: json['totalScore'],
      currentRank: json['currentRank'],
      completedLevelIds: List<int>.from(json['completedLevelIds']),
      levelScores: Map<int, int>.from(json['levelScores']),
      highestUnlockedLevelId: json['highestUnlockedLevelId'],
    );
  }

  // Convert user progress to JSON
  Map<String, dynamic> toJson() {
    return {
      'totalScore': totalScore,
      'currentRank': currentRank,
      'completedLevelIds': completedLevelIds,
      'levelScores': levelScores,
      'highestUnlockedLevelId': highestUnlockedLevelId,
    };
  }

  // Create a copy of this progress with modified properties
  UserProgress copyWith({
    int? totalScore,
    String? currentRank,
    List<int>? completedLevelIds,
    Map<int, int>? levelScores,
    int? highestUnlockedLevelId,
  }) {
    return UserProgress(
      totalScore: totalScore ?? this.totalScore,
      currentRank: currentRank ?? this.currentRank,
      completedLevelIds: completedLevelIds ?? this.completedLevelIds,
      levelScores: levelScores ?? this.levelScores,
      highestUnlockedLevelId: highestUnlockedLevelId ?? this.highestUnlockedLevelId,
    );
  }

  // Add a completed level with score
  UserProgress addCompletedLevel(int levelId, int score) {
    List<int> newCompletedLevelIds = List.from(completedLevelIds);
    Map<int, int> newLevelScores = Map.from(levelScores);
    
    if (!newCompletedLevelIds.contains(levelId)) {
      newCompletedLevelIds.add(levelId);
    }
    
    // Update the score (keep the highest score)
    int previousScore = newLevelScores[levelId] ?? 0;
    if (score > previousScore) {
      newLevelScores[levelId] = score;
    }
    
    // Calculate new total score
    int newTotalScore = 0;
    newLevelScores.forEach((_, value) {
      newTotalScore += value;
    });
    
    // Calculate new highest unlocked level (can only increase)
    int newHighestUnlockedLevelId = highestUnlockedLevelId;
    if (levelId + 1 > highestUnlockedLevelId) {
      newHighestUnlockedLevelId = levelId + 1;
    }
    
    return copyWith(
      totalScore: newTotalScore,
      completedLevelIds: newCompletedLevelIds,
      levelScores: newLevelScores,
      highestUnlockedLevelId: newHighestUnlockedLevelId,
    );
  }

  // Update current rank based on total score
  UserProgress updateRank() {
    String newRank = currentRank;
    
    // Define rank thresholds
    if (totalScore >= 500) {
      newRank = 'Appointed Person';
    } else if (totalScore >= 400) {
      newRank = 'Lift Supervisor';
    } else if (totalScore >= 300) {
      newRank = 'Slinger Signaller';
    } else if (totalScore >= 200) {
      newRank = 'Banksman';
    } else if (totalScore >= 100) {
      newRank = 'Rigger';
    } else {
      newRank = 'Labourer';
    }
    
    return copyWith(currentRank: newRank);
  }
}