// Crane model class to represent different crane types and their specifications

class Crane {
  final int id;
  final String name;
  final String type; // mobile, tower, luffer
  final double maxCapacity; // in tonnes
  final double maxRadius; // in meters
  final double minRadius; // in meters
  final String imageAsset;
  final Map<double, double> loadChart; // radius to capacity mapping
  final double setupTime; // in hours
  final List<String> suitableGroundConditions;
  final bool canOperateAtNight;
  final bool supportsConfinedSpaces;
  final bool supportsTandemLifts;

  Crane({
    required this.id,
    required this.name,
    required this.type,
    required this.maxCapacity,
    required this.maxRadius,
    required this.minRadius,
    required this.imageAsset,
    required this.loadChart,
    required this.setupTime,
    required this.suitableGroundConditions,
    required this.canOperateAtNight,
    required this.supportsConfinedSpaces,
    required this.supportsTandemLifts,
  });

  // Check if the crane can handle a specific lift based on weight and radius
  bool canHandleLift(double weight, double radius) {
    // Find the capacity at the given radius
    // If exact radius is not in the chart, interpolate between the closest values
    if (radius < minRadius || radius > maxRadius) {
      return false;
    }

    if (loadChart.containsKey(radius)) {
      return loadChart[radius]! >= weight;
    } else {
      // Find closest lower and higher radius values
      double lowerRadius = loadChart.keys.where((r) => r < radius).reduce((a, b) => a > b ? a : b);
      double higherRadius = loadChart.keys.where((r) => r > radius).reduce((a, b) => a < b ? a : b);
      
      // Interpolate capacity
      double lowerCapacity = loadChart[lowerRadius]!;
      double higherCapacity = loadChart[higherRadius]!;
      double interpolatedCapacity = lowerCapacity + (higherCapacity - lowerCapacity) * 
                                    (radius - lowerRadius) / (higherRadius - lowerRadius);
      
      return interpolatedCapacity >= weight;
    }
  }

  // Check if crane is suitable for specific ground conditions
  bool isSuitableForGroundCondition(String groundCondition) {
    return suitableGroundConditions.contains(groundCondition);
  }

  // Factory method to create a crane from JSON
  factory Crane.fromJson(Map<String, dynamic> json) {
    return Crane(
      id: json['id'],
      name: json['name'],
      type: json['type'],
      maxCapacity: json['maxCapacity'],
      maxRadius: json['maxRadius'],
      minRadius: json['minRadius'],
      imageAsset: json['imageAsset'],
      loadChart: Map<double, double>.from(json['loadChart']),
      setupTime: json['setupTime'],
      suitableGroundConditions: List<String>.from(json['suitableGroundConditions']),
      canOperateAtNight: json['canOperateAtNight'],
      supportsConfinedSpaces: json['supportsConfinedSpaces'],
      supportsTandemLifts: json['supportsTandemLifts'],
    );
  }

  // Convert crane to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'maxCapacity': maxCapacity,
      'maxRadius': maxRadius,
      'minRadius': minRadius,
      'imageAsset': imageAsset,
      'loadChart': loadChart,
      'setupTime': setupTime,
      'suitableGroundConditions': suitableGroundConditions,
      'canOperateAtNight': canOperateAtNight,
      'supportsConfinedSpaces': supportsConfinedSpaces,
      'supportsTandemLifts': supportsTandemLifts,
    };
  }
}