// Lift Scenario model to represent different lifting operation scenarios

class LiftScenario {
  final int id;
  final String name;
  final String description;
  final double loadWeight; // in tonnes
  final double liftRadius; // in meters
  final String groundCondition; // e.g., 'firm', 'soft', 'uneven'
  final bool isConfinedSpace;
  final bool isTandemLift;
  final bool isNightLift;
  final List<String> safetyRequirements; // List of required safety measures
  final List<int> suitableCraneIds; // IDs of suitable cranes for this scenario
  final String siteLayoutImage; // Image of the site layout
  final List<Map<String, dynamic>> exclusionZones; // Required exclusion zones

  LiftScenario({
    required this.id,
    required this.name,
    required this.description,
    required this.loadWeight,
    required this.liftRadius,
    required this.groundCondition,
    required this.isConfinedSpace,
    required this.isTandemLift,
    required this.isNightLift,
    required this.safetyRequirements,
    required this.suitableCraneIds,
    required this.siteLayoutImage,
    required this.exclusionZones,
  });

  // Factory method to create a lift scenario from JSON
  factory LiftScenario.fromJson(Map<String, dynamic> json) {
    return LiftScenario(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      loadWeight: json['loadWeight'],
      liftRadius: json['liftRadius'],
      groundCondition: json['groundCondition'],
      isConfinedSpace: json['isConfinedSpace'],
      isTandemLift: json['isTandemLift'],
      isNightLift: json['isNightLift'],
      safetyRequirements: List<String>.from(json['safetyRequirements']),
      suitableCraneIds: List<int>.from(json['suitableCraneIds']),
      siteLayoutImage: json['siteLayoutImage'],
      exclusionZones: List<Map<String, dynamic>>.from(json['exclusionZones']),
    );
  }

  // Convert lift scenario to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'loadWeight': loadWeight,
      'liftRadius': liftRadius,
      'groundCondition': groundCondition,
      'isConfinedSpace': isConfinedSpace,
      'isTandemLift': isTandemLift,
      'isNightLift': isNightLift,
      'safetyRequirements': safetyRequirements,
      'suitableCraneIds': suitableCraneIds,
      'siteLayoutImage': siteLayoutImage,
      'exclusionZones': exclusionZones,
    };
  }
}