// Level model class to represent training levels and scenarios

import 'lift_scenario.dart';

class Level {
  final int id;
  final String name;
  final String description;
  final int requiredScore; // Score required to unlock this level
  final LiftScenario liftScenario;
  final String rank; // Rank achieved after completing this level
  final int maxScore; // Maximum possible score for this level
  final bool isLocked;
  final String imageAsset; // Image representing this level

  Level({
    required this.id,
    required this.name,
    required this.description,
    required this.requiredScore,
    required this.liftScenario,
    required this.rank,
    required this.maxScore,
    this.isLocked = true,
    required this.imageAsset,
  });

  // Factory method to create a level from JSON
  factory Level.fromJson(Map<String, dynamic> json) {
    return Level(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      requiredScore: json['requiredScore'],
      liftScenario: LiftScenario.fromJson(json['liftScenario']),
      rank: json['rank'],
      maxScore: json['maxScore'],
      isLocked: json['isLocked'],
      imageAsset: json['imageAsset'],
    );
  }

  // Convert level to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'requiredScore': requiredScore,
      'liftScenario': liftScenario.toJson(),
      'rank': rank,
      'maxScore': maxScore,
      'isLocked': isLocked,
      'imageAsset': imageAsset,
    };
  }

  // Create a copy of this level with modified properties
  Level copyWith({
    int? id,
    String? name,
    String? description,
    int? requiredScore,
    LiftScenario? liftScenario,
    String? rank,
    int? maxScore,
    bool? isLocked,
    String? imageAsset,
  }) {
    return Level(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      requiredScore: requiredScore ?? this.requiredScore,
      liftScenario: liftScenario ?? this.liftScenario,
      rank: rank ?? this.rank,
      maxScore: maxScore ?? this.maxScore,
      isLocked: isLocked ?? this.isLocked,
      imageAsset: imageAsset ?? this.imageAsset,
    );
  }
}