# Appointed Person (AP) Training App

A Flutter-based mobile application for training Appointed Persons (AP) for lifting operations in the UK, following LOLER and BS 7121 standards.

## Features

- **Level-based progression**: Each level is a new lifting scenario, starting simple and becoming more complex (e.g., confined site, tandem lift, night lift)
- **Crane selection logic**: Choose from various crane types (mobile, tower, luffer), each with different specifications
- **Load input system**: Input load weight, radius, and ground condition details
- **Scoring system**: Score based on correct crane selection and safety measures
- **Progress tracking**: Monitor your rank progression from "Labourer" to "Appointed Person"
- **Offline capability**: App stores progress locally

## App Structure

### Models

- `crane.dart`: Represents different types of cranes and their specifications
- `level.dart`: Represents training levels and their requirements
- `lift_scenario.dart`: Contains details about lifting scenarios for each level
- `user_progress.dart`: Tracks user's achievements and progress

### Services

- `storage_service.dart`: Handles local storage for offline capability

### Providers

- `app_state_provider.dart`: Manages app state using the Provider pattern

### Screens

- `home_screen.dart`: Main entry point with app overview and progress summary
- `level_selection_screen.dart`: Grid display of all available levels
- `level_detail_screen.dart`: Details about a specific level and its challenges
- `crane_selection_screen.dart`: Interface for selecting the appropriate crane
- `level_completion_screen.dart`: Shows results and score after completing a level
- `progress_screen.dart`: Detailed view of user progress and achievements

### Utils

- `sample_data.dart`: Provides sample data for cranes and levels

## How to Run

1. Ensure Flutter is installed on your system
2. Clone this repository
3. Run `flutter pub get` to install dependencies
4. Connect a device or emulator
5. Run `flutter run` to start the app

## Future Enhancements

- Implement drag-to-place exclusion zones
- Add more crane types and specifications
- Include more complex lifting scenarios
- Add tutorial mode for beginners
- Implement detailed feedback on crane selection choices