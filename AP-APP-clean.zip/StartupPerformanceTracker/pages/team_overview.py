import streamlit as st
import pandas as pd
import altair as alt
import datetime

# Import utility functions
from utils import load_data, calculate_team_metrics

# Page configuration
st.set_page_config(
    page_title="Team Overview - Performance Tracker",
    page_icon="📊",
    layout="wide",
)

# Get data
team_members, metrics = load_data()

# Page title
st.title("Team Overview")
st.write("View aggregated performance metrics by team")

# Date range selector
st.sidebar.header("Date Range")
start_date = st.sidebar.date_input("Start Date", st.session_state.get('start_date', datetime.date.today() - datetime.timedelta(days=30)))
end_date = st.sidebar.date_input("End Date", st.session_state.get('end_date', datetime.date.today()))

if start_date > end_date:
    st.error("Error: End date must be after start date")
    st.stop()

# Store date range in session state
st.session_state.start_date = start_date
st.session_state.end_date = end_date

# If we have no metrics data yet, show a message
if metrics.empty:
    st.info("No performance data has been entered yet. Please add team member performance data in the Individual Metrics page.")
    
    # Show sample visualization with dummy data
    st.subheader("Sample Team Overview (Example Data)")
    
    # Create some sample data
    sample_teams = ["Engineering", "Design", "Product", "Marketing", "Data Science"]
    sample_data = pd.DataFrame({
        'team': sample_teams,
        'productivity': [85, 82, 88, 79, 91],
        'quality': [90, 94, 85, 82, 88],
        'satisfaction': [78, 85, 80, 83, 79],
        'tasks_completed': [45, 32, 28, 36, 40]
    })
    
    # Display sample metrics
    st.write("This is an example of how your data will look once you add metrics:")
    
    # Sample team metrics summary
    st.subheader("Team Performance Summary (Example)")
    cols = st.columns(len(sample_teams))
    
    for i, team in enumerate(sample_teams):
        team_data = sample_data[sample_data['team'] == team].iloc[0]
        with cols[i]:
            st.metric(label=team, value=f"{team_data['productivity']}%", 
                     delta=f"{5 if i % 2 == 0 else -3}%")
    
    # Sample chart
    st.subheader("Team Productivity Comparison (Example)")
    chart = alt.Chart(sample_data).mark_bar().encode(
        x=alt.X('team:N', title='Team'),
        y=alt.Y('productivity:Q', title='Productivity (%)'),
        color=alt.Color('team:N', legend=None),
        tooltip=['team', 'productivity']
    ).properties(height=400)
    
    st.altair_chart(chart, use_container_width=True)
    
    st.caption("Note: This is example data. Add your own team metrics to see real data.")
else:
    # Filter metrics by date range
    filtered_metrics = metrics[
        (metrics['date'] >= pd.Timestamp(start_date)) & 
        (metrics['date'] <= pd.Timestamp(end_date))
    ]
    
    if filtered_metrics.empty:
        st.warning(f"No data available for the selected date range ({start_date} to {end_date}).")
    else:
        # Calculate team metrics
        team_metrics = calculate_team_metrics(filtered_metrics)
        
        # Team selection for detailed view
        teams = team_metrics['team'].unique().tolist()
        selected_team = st.sidebar.selectbox("Select Team for Details", teams)
        
        # Display overall metrics
        st.subheader("Team Performance Summary")
        cols = st.columns(len(teams))
        
        for i, team in enumerate(teams):
            team_data = team_metrics[team_metrics['team'] == team].iloc[0]
            with cols[i]:
                st.metric(label=team, value=f"{team_data['productivity']}%")
        
        # Productivity comparison
        st.subheader("Team Productivity Comparison")
        chart = alt.Chart(team_metrics).mark_bar().encode(
            x=alt.X('team:N', title='Team'),
            y=alt.Y('productivity:Q', title='Productivity (%)'),
            color=alt.Color('team:N', legend=None),
            tooltip=['team', 'productivity']
        ).properties(height=400)
        
        st.altair_chart(chart, use_container_width=True)
        
        # Quality and satisfaction metrics
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Quality Ratings by Team")
            quality_chart = alt.Chart(team_metrics).mark_bar().encode(
                x=alt.X('team:N', title='Team'),
                y=alt.Y('quality:Q', title='Quality (%)'),
                color=alt.Color('team:N', legend=None),
                tooltip=['team', 'quality']
            ).properties(height=300)
            
            st.altair_chart(quality_chart, use_container_width=True)
        
        with col2:
            st.subheader("Satisfaction Ratings by Team")
            satisfaction_chart = alt.Chart(team_metrics).mark_bar().encode(
                x=alt.X('team:N', title='Team'),
                y=alt.Y('satisfaction:Q', title='Satisfaction (%)'),
                color=alt.Color('team:N', legend=None),
                tooltip=['team', 'satisfaction']
            ).properties(height=300)
            
            st.altair_chart(satisfaction_chart, use_container_width=True)
        
        # Detailed view for selected team
        st.header(f"Detailed View: {selected_team}")
        
        # Get team members
        team_members_filtered = team_members[team_members['team'] == selected_team]
        
        # Get metrics for those team members
        team_members_ids = team_members_filtered['id'].tolist()
        team_member_metrics = filtered_metrics[filtered_metrics['team_member_id'].isin(team_members_ids)]
        
        if team_member_metrics.empty:
            st.info(f"No detailed data available for {selected_team} in the selected date range.")
        else:
            # Individual performance within team
            st.subheader("Individual Performance")
            
            # Merge data to get names
            individual_metrics = pd.merge(
                team_member_metrics,
                team_members_filtered[['id', 'name']],
                left_on='team_member_id',
                right_on='id'
            )
            
            # Calculate average metrics by individual
            individual_avg = individual_metrics.groupby('name').agg({
                'productivity': 'mean',
                'quality': 'mean',
                'satisfaction': 'mean',
                'tasks_completed': 'sum'
            }).reset_index()
            
            # Format percentage columns
            for col in ['productivity', 'quality', 'satisfaction']:
                individual_avg[col] = (individual_avg[col] * 100).round(1)
            
            # Display as a table
            st.dataframe(individual_avg)
            
            # Trend over time
            st.subheader("Team Productivity Trend")
            
            # Prepare data for time series
            time_data = individual_metrics.groupby('date')['productivity'].mean().reset_index()
            time_data['productivity'] = (time_data['productivity'] * 100).round(1)
            
            # Create time series chart
            time_chart = alt.Chart(time_data).mark_line(point=True).encode(
                x=alt.X('date:T', title='Date'),
                y=alt.Y('productivity:Q', title='Average Productivity (%)', scale=alt.Scale(domain=[60, 100])),
                tooltip=['date', 'productivity']
            ).properties(height=300)
            
            st.altair_chart(time_chart, use_container_width=True)
