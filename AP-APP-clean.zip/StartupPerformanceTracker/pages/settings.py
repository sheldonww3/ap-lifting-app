import streamlit as st
import pandas as pd
import uuid

# Import utility functions
from utils import load_data, save_data

# Page configuration
st.set_page_config(
    page_title="Settings - Performance Tracker",
    page_icon="⚙️",
)

# Get data
team_members, metrics = load_data()

# Page title
st.title("Settings")
st.write("Manage your team members and application settings")

# Team Member Management
st.header("Team Member Management")

# Add new team member form
st.subheader("Add New Team Member")
col1, col2 = st.columns(2)

with col1:
    name = st.text_input("Name")
    
    # Get existing teams for dropdown
    existing_teams = sorted(team_members['team'].unique().tolist()) if not team_members.empty else []
    
    # Allow selecting existing team or adding a new one
    team_option = st.radio(
        "Team",
        options=["Select Existing", "Create New"],
        horizontal=True
    )
    
    if team_option == "Select Existing" and existing_teams:
        team = st.selectbox("Select Team", existing_teams)
    else:
        team = st.text_input("Team Name")

with col2:
    role = st.text_input("Role")
    st.write("") # Spacing
    st.write("") # Spacing
    # Add button for the form
    add_member = st.button("Add Team Member")

if add_member:
    if not name or not role or not team:
        st.error("Please fill in all fields")
    else:
        # Initialize team members DataFrame if it doesn't exist
        if team_members.empty:
            team_members = pd.DataFrame(columns=['id', 'name', 'role', 'team'])
        
        # Create new team member
        new_member = {
            'id': team_members['id'].max() + 1 if not team_members.empty else 1,
            'name': name,
            'role': role,
            'team': team
        }
        
        # Add to DataFrame
        team_members = pd.concat([team_members, pd.DataFrame([new_member])], ignore_index=True)
        
        # Save data
        save_data(team_members, metrics)
        
        st.success(f"Added {name} to the team!")
        st.rerun()

# View and manage existing team members
st.subheader("Manage Team Members")

if team_members.empty:
    st.info("No team members added yet. Use the form above to add your first team member.")
else:
    # Filter option
    team_filter = st.selectbox(
        "Filter by Team",
        options=["All Teams"] + sorted(team_members['team'].unique().tolist())
    )
    
    # Apply filter
    filtered_members = team_members
    if team_filter != "All Teams":
        filtered_members = team_members[team_members['team'] == team_filter]
    
    # Show team members
    st.dataframe(filtered_members[['name', 'role', 'team']], use_container_width=True)
    
    # Edit team member
    st.subheader("Edit Team Member")
    member_to_edit = st.selectbox(
        "Select a team member to edit",
        options=filtered_members['id'].tolist(),
        format_func=lambda x: f"{team_members.loc[team_members['id'] == x, 'name'].iloc[0]} ({team_members.loc[team_members['id'] == x, 'role'].iloc[0]})"
    )
    
    # Get current values
    current_name = team_members.loc[team_members['id'] == member_to_edit, 'name'].iloc[0]
    current_role = team_members.loc[team_members['id'] == member_to_edit, 'role'].iloc[0]
    current_team = team_members.loc[team_members['id'] == member_to_edit, 'team'].iloc[0]
    
    # Edit form
    col1, col2 = st.columns(2)
    
    with col1:
        new_name = st.text_input("Name", value=current_name, key="edit_name")
        
        # Team selection
        team_edit_option = st.radio(
            "Team",
            options=["Keep Current", "Select Different", "Create New"],
            horizontal=True,
            key="edit_team_option"
        )
        
        if team_edit_option == "Keep Current":
            new_team = current_team
        elif team_edit_option == "Select Different":
            new_team = st.selectbox(
                "Select Team", 
                sorted(team_members['team'].unique().tolist()),
                index=sorted(team_members['team'].unique().tolist()).index(current_team) 
                    if current_team in team_members['team'].unique().tolist() else 0
            )
        else:
            new_team = st.text_input("New Team Name")
    
    with col2:
        new_role = st.text_input("Role", value=current_role, key="edit_role")
        st.write("") # Spacing
        st.write("") # Spacing
        update_button = st.button("Update Team Member")
    
    if update_button:
        if not new_name or not new_role or not new_team:
            st.error("Please fill in all fields")
        else:
            # Update team member
            team_members.loc[team_members['id'] == member_to_edit, 'name'] = new_name
            team_members.loc[team_members['id'] == member_to_edit, 'role'] = new_role
            team_members.loc[team_members['id'] == member_to_edit, 'team'] = new_team
            
            # Update team in metrics too if it exists
            if not metrics.empty:
                member_metrics_indices = metrics['team_member_id'] == member_to_edit
                metrics.loc[member_metrics_indices, 'team'] = new_team
            
            # Save data
            save_data(team_members, metrics)
            
            st.success(f"Updated information for {new_name}!")
            st.rerun()
    
    # Delete team member
    st.subheader("Delete Team Member")
    st.warning("Caution: Deleting a team member will also remove all associated performance metrics!")
    
    member_to_delete = st.selectbox(
        "Select a team member to delete",
        options=filtered_members['id'].tolist(),
        format_func=lambda x: f"{team_members.loc[team_members['id'] == x, 'name'].iloc[0]} ({team_members.loc[team_members['id'] == x, 'role'].iloc[0]})",
        key="delete_member"
    )
    
    confirm_delete = st.checkbox("I understand this action cannot be undone")
    
    if st.button("Delete Team Member") and confirm_delete:
        # Remove team member
        team_members = team_members[team_members['id'] != member_to_delete]
        
        # Remove associated metrics
        if not metrics.empty:
            metrics = metrics[metrics['team_member_id'] != member_to_delete]
        
        # Save data
        save_data(team_members, metrics)
        
        st.success("Team member deleted successfully!")
        st.rerun()

# Application Settings
st.header("Application Settings")
st.subheader("Data Management")

# Export all data
if not team_members.empty or not metrics.empty:
    if st.button("Reset All Data"):
        # Confirm deletion
        confirm = st.checkbox("I understand this will delete all team members and performance data")
        
        if confirm and st.button("Confirm Reset"):
            # Reset data
            save_data(pd.DataFrame(), pd.DataFrame())
            st.success("All data has been reset!")
            st.rerun()
