import streamlit as st
import pandas as pd
import datetime
import uuid

# Import utility functions
from utils import load_data, save_data

# Page configuration
st.set_page_config(
    page_title="Individual Metrics - Performance Tracker",
    page_icon="📊",
)

# Get data
team_members, metrics = load_data()

# Page title
st.title("Individual Performance Metrics")
st.write("Add and update performance metrics for individual team members")

# If no team members exist, prompt to add them first
if team_members.empty:
    st.warning("No team members found. Please add team members in the Settings page first.")
    st.stop()

# Sidebar for filter options
st.sidebar.header("Filters")
selected_team = st.sidebar.selectbox(
    "Filter by Team",
    options=["All Teams"] + sorted(team_members['team'].unique().tolist())
)

# Filter team members based on selection
filtered_team_members = team_members
if selected_team != "All Teams":
    filtered_team_members = team_members[team_members['team'] == selected_team]

# Entry form for adding new metrics
st.header("Add New Performance Metrics")

# Multi-select for team members
selected_members = st.multiselect(
    "Select Team Members",
    options=filtered_team_members['id'].tolist(),
    format_func=lambda x: team_members.loc[team_members['id'] == x, 'name'].iloc[0] + 
               f" ({team_members.loc[team_members['id'] == x, 'role'].iloc[0]} - {team_members.loc[team_members['id'] == x, 'team'].iloc[0]})"
)

# Date selection
metric_date = st.date_input("Date", datetime.date.today())

# Create columns for metrics
col1, col2 = st.columns(2)

with col1:
    productivity = st.slider("Productivity (%)", 0, 100, 85) / 100
    quality = st.slider("Quality of Work (%)", 0, 100, 90) / 100

with col2:
    satisfaction = st.slider("Job Satisfaction (%)", 0, 100, 80) / 100
    tasks_completed = st.number_input("Tasks Completed", 0, 100, 5)

notes = st.text_area("Notes (Optional)", "", help="Add any additional notes about performance")

# Add metrics button
if st.button("Add Metrics"):
    if not selected_members:
        st.error("Please select at least one team member.")
    else:
        # Initialize metrics DataFrame if it doesn't exist
        if metrics.empty:
            metrics = pd.DataFrame(columns=[
                'id', 'team_member_id', 'date', 'productivity', 'quality', 
                'satisfaction', 'tasks_completed', 'notes', 'team'
            ])
        
        # Add entries for each selected team member
        new_entries = []
        for member_id in selected_members:
            # Get team from the team member
            member_team = team_members.loc[team_members['id'] == member_id, 'team'].iloc[0]
            
            new_entry = {
                'id': str(uuid.uuid4()),
                'team_member_id': member_id,
                'date': pd.Timestamp(metric_date),
                'productivity': productivity,
                'quality': quality,
                'satisfaction': satisfaction,
                'tasks_completed': tasks_completed,
                'notes': notes,
                'team': member_team
            }
            new_entries.append(new_entry)
        
        # Append new entries to metrics DataFrame
        metrics = pd.concat([metrics, pd.DataFrame(new_entries)], ignore_index=True)
        
        # Save updated metrics
        save_data(team_members, metrics)
        
        st.success(f"Added metrics for {len(selected_members)} team member(s)!")
        st.rerun()

# View existing metrics
st.header("View Existing Metrics")

if metrics.empty:
    st.info("No metrics have been added yet. Use the form above to add performance metrics.")
else:
    # Add date range filter
    start_date = st.sidebar.date_input(
        "Start Date", 
        st.session_state.get('start_date', datetime.date.today() - datetime.timedelta(days=30))
    )
    end_date = st.sidebar.date_input(
        "End Date", 
        st.session_state.get('end_date', datetime.date.today())
    )
    
    if start_date > end_date:
        st.sidebar.error("End date must be after start date")
    else:
        # Filter metrics by date and team
        filtered_metrics = metrics[
            (metrics['date'] >= pd.Timestamp(start_date)) & 
            (metrics['date'] <= pd.Timestamp(end_date))
        ]
        
        if selected_team != "All Teams":
            filtered_metrics = filtered_metrics[filtered_metrics['team'] == selected_team]
        
        if filtered_metrics.empty:
            st.info("No metrics found for the selected filters.")
        else:
            # Merge with team member data to show names
            display_metrics = pd.merge(
                filtered_metrics,
                team_members[['id', 'name', 'role', 'team']],
                left_on='team_member_id',
                right_on='id',
                suffixes=('', '_member')
            )
            
            # Prepare display columns
            display_columns = [
                'date', 'name', 'team', 'role', 
                'productivity', 'quality', 'satisfaction', 
                'tasks_completed', 'notes'
            ]
            
            # Format percentage columns
            display_metrics_formatted = display_metrics[display_columns].copy()
            for col in ['productivity', 'quality', 'satisfaction']:
                display_metrics_formatted[col] = (display_metrics_formatted[col] * 100).round(1).astype(str) + '%'
            
            # Show the data
            st.dataframe(
                display_metrics_formatted.sort_values(by=['date', 'name'], ascending=[False, True]),
                use_container_width=True
            )
            
            # Option to delete entries
            st.subheader("Delete Metrics")
            st.warning("Caution: Deletion is permanent")
            
            metrics_to_delete = st.multiselect(
                "Select metrics to delete",
                options=filtered_metrics['id'].tolist(),
                format_func=lambda x: (
                    f"{metrics[metrics['id'] == x]['date'].iloc[0].strftime('%Y-%m-%d')} - "
                    f"{team_members.loc[team_members['id'] == metrics[metrics['id'] == x]['team_member_id'].iloc[0], 'name'].iloc[0]}"
                )
            )
            
            if st.button("Delete Selected Metrics"):
                if metrics_to_delete:
                    # Remove selected metrics
                    metrics = metrics[~metrics['id'].isin(metrics_to_delete)]
                    save_data(team_members, metrics)
                    st.success(f"Deleted {len(metrics_to_delete)} metric entries!")
                    st.rerun()
                else:
                    st.error("No metrics selected for deletion.")
