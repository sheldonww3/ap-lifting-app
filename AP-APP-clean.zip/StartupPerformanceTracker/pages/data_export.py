import streamlit as st
import pandas as pd
import altair as alt
import datetime

# Import utility functions
from utils import load_data, get_csv_download_link, get_excel_download_link

# Page configuration
st.set_page_config(
    page_title="Data Export - Performance Tracker",
    page_icon="📊",
)

# Get data
team_members, metrics = load_data()

# Page title
st.title("Data Export")
st.write("Generate reports and export your team performance data")

# Check if we have data
if metrics.empty:
    st.warning("No performance data has been added yet. Please add metrics in the Individual Metrics page first.")
    st.stop()

# Filters for export
st.sidebar.header("Export Filters")

# Date range
start_date = st.sidebar.date_input(
    "Start Date", 
    st.session_state.get('start_date', datetime.date.today() - datetime.timedelta(days=30))
)
end_date = st.sidebar.date_input(
    "End Date", 
    st.session_state.get('end_date', datetime.date.today())
)

# Team filter
all_teams = sorted(team_members['team'].unique().tolist())
selected_teams = st.sidebar.multiselect(
    "Select Teams",
    options=all_teams,
    default=all_teams
)

# Apply filters
filtered_metrics = metrics
if start_date and end_date:
    if start_date > end_date:
        st.error("Error: End date must be after start date")
    else:
        filtered_metrics = filtered_metrics[
            (filtered_metrics['date'] >= pd.Timestamp(start_date)) & 
            (filtered_metrics['date'] <= pd.Timestamp(end_date))
        ]

if selected_teams:
    # Get team member IDs for selected teams
    team_members_filtered = team_members[team_members['team'].isin(selected_teams)]
    team_member_ids = team_members_filtered['id'].tolist()
    filtered_metrics = filtered_metrics[filtered_metrics['team_member_id'].isin(team_member_ids)]

# Check if we have data after filtering
if filtered_metrics.empty:
    st.warning("No data available for the selected filters.")
    st.stop()

# Merge data for better display
merged_data = pd.merge(
    filtered_metrics,
    team_members[['id', 'name', 'role', 'team']],
    left_on='team_member_id',
    right_on='id',
    suffixes=('', '_member')
)

# Format data for export
export_data = merged_data.copy()
export_data = export_data.rename(columns={
    'name': 'Employee Name',
    'role': 'Job Role',
    'team': 'Team',
    'date': 'Date',
    'productivity': 'Productivity',
    'quality': 'Quality',
    'satisfaction': 'Satisfaction',
    'tasks_completed': 'Tasks Completed',
    'notes': 'Notes'
})

# Convert percentages to 0-100 scale
for col in ['Productivity', 'Quality', 'Satisfaction']:
    export_data[col] = (export_data[col] * 100).round(1)

# Select columns for export
export_columns = [
    'Date', 'Employee Name', 'Team', 'Job Role',
    'Productivity', 'Quality', 'Satisfaction', 'Tasks Completed', 'Notes'
]
export_data = export_data[export_columns]

# Display data preview
st.header("Data Preview")
st.dataframe(export_data.head(10), use_container_width=True)
st.info(f"Total records: {len(export_data)}")

# Export options
st.header("Export Options")

col1, col2 = st.columns(2)

with col1:
    # CSV Export
    st.subheader("CSV Export")
    filename = st.text_input("CSV Filename", "team_performance_data.csv")
    st.markdown(get_csv_download_link(export_data, filename, "Download CSV"), unsafe_allow_html=True)

with col2:
    # Excel Export
    st.subheader("Excel Export")
    excel_filename = st.text_input("Excel Filename", "team_performance_data.xlsx")
    st.markdown(get_excel_download_link(export_data, excel_filename, "Download Excel"), unsafe_allow_html=True)

# Report generation
st.header("Performance Reports")

# Report Type
report_type = st.selectbox(
    "Select Report Type",
    options=["Individual Performance", "Team Comparison", "Trend Analysis"]
)

if report_type == "Individual Performance":
    # Select employee
    employees = sorted(merged_data['name'].unique().tolist())
    selected_employee = st.selectbox("Select Employee", employees)
    
    # Filter data for selected employee
    employee_data = merged_data[merged_data['name'] == selected_employee]
    
    # Display performance metrics
    st.subheader(f"Performance Report: {selected_employee}")
    
    # Summary statistics
    avg_productivity = (employee_data['productivity'].mean() * 100).round(1)
    avg_quality = (employee_data['quality'].mean() * 100).round(1)
    avg_satisfaction = (employee_data['satisfaction'].mean() * 100).round(1)
    total_tasks = employee_data['tasks_completed'].sum()
    
    # Display metrics
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Avg. Productivity", f"{avg_productivity}%")
    col2.metric("Avg. Quality", f"{avg_quality}%")
    col3.metric("Avg. Satisfaction", f"{avg_satisfaction}%")
    col4.metric("Total Tasks", total_tasks)
    
    # Performance over time
    st.subheader("Performance Over Time")
    
    # Prepare data for chart
    chart_data = employee_data.copy()
    for col in ['productivity', 'quality', 'satisfaction']:
        chart_data[col] = chart_data[col] * 100
    
    # Long format for Altair
    chart_data_long = pd.melt(
        chart_data, 
        id_vars=['date'],
        value_vars=['productivity', 'quality', 'satisfaction'],
        var_name='metric',
        value_name='value'
    )
    
    # Create line chart
    chart = alt.Chart(chart_data_long).mark_line(point=True).encode(
        x=alt.X('date:T', title='Date'),
        y=alt.Y('value:Q', title='Percentage (%)'),
        color=alt.Color('metric:N', title='Metric', 
                        scale=alt.Scale(domain=['productivity', 'quality', 'satisfaction'],
                                       range=['#4C78A8', '#72B7B2', '#F58518'])),
        tooltip=['date', 'metric', 'value']
    ).properties(height=400)
    
    st.altair_chart(chart, use_container_width=True)
    
    # Tasks completed over time
    st.subheader("Tasks Completed Over Time")
    tasks_chart = alt.Chart(chart_data).mark_bar().encode(
        x=alt.X('date:T', title='Date'),
        y=alt.Y('tasks_completed:Q', title='Tasks Completed'),
        tooltip=['date', 'tasks_completed']
    ).properties(height=300)
    
    st.altair_chart(tasks_chart, use_container_width=True)
    
elif report_type == "Team Comparison":
    # Team comparison report
    st.subheader("Team Performance Comparison")
    
    # Calculate team averages
    team_data = merged_data.groupby('team').agg({
        'productivity': 'mean',
        'quality': 'mean',
        'satisfaction': 'mean',
        'tasks_completed': 'sum'
    }).reset_index()
    
    # Format percentages
    for col in ['productivity', 'quality', 'satisfaction']:
        team_data[col] = (team_data[col] * 100).round(1)
    
    # Display team comparison
    st.dataframe(team_data, use_container_width=True)
    
    # Bar charts for comparison
    metrics_to_plot = st.multiselect(
        "Select Metrics to Compare",
        options=['productivity', 'quality', 'satisfaction'],
        default=['productivity']
    )
    
    if metrics_to_plot:
        # Long format for selected metrics
        plot_data = pd.melt(
            team_data,
            id_vars=['team'],
            value_vars=metrics_to_plot,
            var_name='metric',
            value_name='value'
        )
        
        # Create chart
        chart = alt.Chart(plot_data).mark_bar().encode(
            x=alt.X('team:N', title='Team'),
            y=alt.Y('value:Q', title='Value (%)'),
            color=alt.Color('team:N', legend=None),
            column=alt.Column('metric:N', title='Metric'),
            tooltip=['team', 'metric', 'value']
        ).properties(width=200)
        
        st.altair_chart(chart)
    
    # Tasks completed by team
    st.subheader("Total Tasks Completed by Team")
    tasks_chart = alt.Chart(team_data).mark_bar().encode(
        x=alt.X('team:N', title='Team'),
        y=alt.Y('tasks_completed:Q', title='Tasks Completed'),
        color=alt.Color('team:N', legend=None),
        tooltip=['team', 'tasks_completed']
    ).properties(height=300)
    
    st.altair_chart(tasks_chart, use_container_width=True)
    
elif report_type == "Trend Analysis":
    # Trend analysis over time
    st.subheader("Performance Trends Over Time")
    
    # Calculate daily averages
    daily_data = merged_data.groupby('date').agg({
        'productivity': 'mean',
        'quality': 'mean',
        'satisfaction': 'mean',
        'tasks_completed': 'sum'
    }).reset_index()
    
    # Format percentages
    for col in ['productivity', 'quality', 'satisfaction']:
        daily_data[col] = (daily_data[col] * 100).round(1)
    
    # Metric selection
    selected_metric = st.selectbox(
        "Select Metric to Analyze",
        options=[
            ('productivity', 'Productivity'), 
            ('quality', 'Quality'), 
            ('satisfaction', 'Satisfaction'),
            ('tasks_completed', 'Tasks Completed')
        ],
        format_func=lambda x: x[1]
    )
    
    metric_column, metric_name = selected_metric
    
    # Create trend chart
    st.subheader(f"{metric_name} Trend")
    
    trend_chart = alt.Chart(daily_data).mark_line(point=True).encode(
        x=alt.X('date:T', title='Date'),
        y=alt.Y(f'{metric_column}:Q', title=f'{metric_name}' + (' (%)' if metric_column != 'tasks_completed' else '')),
        tooltip=['date', metric_column]
    ).properties(height=400)
    
    # Add trend line
    trend_line = trend_chart.transform_regression('date', metric_column).mark_line(
        color='red'
    ).encode(
        x='date:T',
        y=metric_column
    )
    
    st.altair_chart(trend_chart + trend_line, use_container_width=True)
    
    # Calculate and display trend statistics
    if len(daily_data) > 1:
        first_value = daily_data.iloc[0][metric_column]
        last_value = daily_data.iloc[-1][metric_column]
        change = last_value - first_value
        percent_change = (change / first_value * 100) if first_value > 0 else 0
        
        st.metric(
            label=f"Overall {metric_name} Change",
            value=f"{change:.1f}" + (' %' if metric_column != 'tasks_completed' else ''),
            delta=f"{percent_change:.1f}%"
        )
        
        # Calculate rolling average
        if len(daily_data) >= 7:
            daily_data[f'{metric_column}_7day_avg'] = daily_data[metric_column].rolling(7, min_periods=1).mean()
            
            # Display rolling average
            st.subheader(f"7-Day Rolling Average: {metric_name}")
            rolling_chart = alt.Chart(daily_data).mark_line(color='green').encode(
                x=alt.X('date:T', title='Date'),
                y=alt.Y(f'{metric_column}_7day_avg:Q', title=f'7-Day Avg {metric_name}' + (' (%)' if metric_column != 'tasks_completed' else '')),
                tooltip=['date', f'{metric_column}_7day_avg']
            ).properties(height=300)
            
            st.altair_chart(rolling_chart, use_container_width=True)
