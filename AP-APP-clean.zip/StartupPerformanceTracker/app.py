import streamlit as st
import os
import base64

# Configure page settings
st.set_page_config(
    page_title="Appointed Person Training App",
    page_icon="🏗️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom function to read file content
def read_file(file_path):
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except Exception as e:
        return f"Error reading file: {e}"

# Function to display code with syntax highlighting
def display_code(code, language="dart"):
    st.code(code, language=language)

# Function to get image file as base64
def get_image_base64(img_path):
    try:
        with open(img_path, "rb") as image_file:
            encoded = base64.b64encode(image_file.read()).decode()
        return f"data:image/svg+xml;base64,{encoded}"
    except Exception as e:
        return None

# Main page header
st.title("Appointed Person (AP) Training App")
st.write("A Flutter mobile application for training Appointed Persons (AP) for lifting operations in the UK")

# Description
st.markdown("""
This app helps users train to become an Appointed Person (AP) for lifting operations 
in the UK, following LOLER and BS 7121 standards. The app includes level-based progression, 
crane selection logic, scoring system, and progress tracking.
""")

# App Structure
st.header("App Structure")

# Display app structure
col1, col2 = st.columns(2)

with col1:
    st.subheader("Core Features")
    st.markdown("""
    - **Level-based progression**: Each level is a new lifting scenario
    - **Crane selection logic**: Choose from various crane types
    - **Load input system**: Input load weight, radius, and ground conditions
    - **Scoring system**: Based on crane selection and safety measures
    - **Progress tracking**: From "Labourer" to "Appointed Person"
    - **Offline capability**: Local storage for user progress
    """)

with col2:
    # Display placeholder image if available
    img_path = "ap_training_app/assets/images/placeholder.svg"
    img_base64 = get_image_base64(img_path)
    if img_base64:
        st.markdown(f'<img src="{img_base64}" width="200">', unsafe_allow_html=True)
    else:
        st.image("https://via.placeholder.com/200x200.png?text=App+Icon", width=200)

# Technical details
st.header("Technical Implementation")

# Create tabs for different code sections
tab1, tab2, tab3, tab4, tab5 = st.tabs(["Models", "Screens", "Providers", "Services", "Utils"])

with tab1:
    st.subheader("Models")
    model_files = ["crane.dart", "level.dart", "lift_scenario.dart", "user_progress.dart"]
    
    for file in model_files:
        with st.expander(f"{file}"):
            file_path = os.path.join("ap_training_app", "lib", "models", file)
            code = read_file(file_path)
            display_code(code)

with tab2:
    st.subheader("Screens")
    screen_files = ["home_screen.dart", "level_selection_screen.dart", "level_detail_screen.dart", 
                   "crane_selection_screen.dart", "level_completion_screen.dart", "progress_screen.dart"]
    
    for file in screen_files:
        with st.expander(f"{file}"):
            file_path = os.path.join("ap_training_app", "lib", "screens", file)
            code = read_file(file_path)
            display_code(code)

with tab3:
    st.subheader("Providers")
    file_path = os.path.join("ap_training_app", "lib", "providers", "app_state_provider.dart")
    code = read_file(file_path)
    display_code(code)

with tab4:
    st.subheader("Services")
    file_path = os.path.join("ap_training_app", "lib", "services", "storage_service.dart")
    code = read_file(file_path)
    display_code(code)

with tab5:
    st.subheader("Utils")
    file_path = os.path.join("ap_training_app", "lib", "utils", "sample_data.dart")
    code = read_file(file_path)
    display_code(code)

# How to run section
st.header("Running the App")
st.markdown("""
To run this Flutter app:

1. Ensure Flutter is installed on your system
2. Navigate to the `ap_training_app` directory
3. Run `flutter pub get` to install dependencies
4. Connect a device or emulator
5. Run `flutter run` to start the app
""")

# Add sidebar for additional information
st.sidebar.title("About")
st.sidebar.info("""
**Appointed Person Training App**

This Flutter app is designed for training Appointed Persons (AP) for lifting operations 
in the UK, following LOLER and BS 7121 standards.

The code structure follows a modular approach with:
- Models for data representation
- Services for external operations
- Providers for state management
- Screens for UI components
- Utils for helper functions
""")

st.sidebar.title("Technical Stack")
st.sidebar.markdown("""
- **Flutter**: UI framework
- **Dart**: Programming language
- **Provider**: State management
- **Shared Preferences**: Local storage
""")

# Footer
st.markdown("---")
st.markdown("© 2025 Appointed Person Training App")
