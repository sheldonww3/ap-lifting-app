import streamlit as st
import pandas as pd
import datetime
import io
import base64

def load_data():
    """
    Load data from the database or storage.
    In a real application, this would connect to a database.
    Currently using session state as a mock database.
    """
    # This function would typically load data from a database
    # For now, we're just returning what's in session state
    return st.session_state.get('team_members', pd.DataFrame()), st.session_state.get('metrics', pd.DataFrame())

def save_data(team_members, metrics):
    """
    Save data to the database or storage.
    In a real application, this would connect to a database.
    Currently using session state as a mock database.
    """
    # This function would typically save data to a database
    # For now, we're just updating session state
    st.session_state.team_members = team_members
    st.session_state.metrics = metrics

def get_csv_download_link(df, filename, link_text):
    """
    Generate a link to download the dataframe as a CSV file
    """
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">{link_text}</a>'
    return href

def get_excel_download_link(df, filename, link_text):
    """
    Generate a link to download the dataframe as an Excel file
    """
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
    excel_data = output.getvalue()
    b64 = base64.b64encode(excel_data).decode()
    href = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="{filename}">{link_text}</a>'
    return href

def calculate_team_metrics(metrics_df):
    """
    Calculate aggregated team metrics
    """
    if metrics_df.empty:
        return pd.DataFrame()
    
    # Group by team and calculate averages
    team_metrics = metrics_df.groupby('team').agg({
        'productivity': 'mean',
        'quality': 'mean',
        'satisfaction': 'mean',
        'tasks_completed': 'sum'
    }).reset_index()
    
    # Round percentage values
    for col in ['productivity', 'quality', 'satisfaction']:
        team_metrics[col] = (team_metrics[col] * 100).round(1)
    
    return team_metrics

def generate_date_range(start_date, end_date):
    """
    Generate a list of dates between start_date and end_date
    """
    date_list = []
    current_date = start_date
    while current_date <= end_date:
        date_list.append(current_date)
        current_date += datetime.timedelta(days=1)
    return date_list

def format_metric_for_display(value, metric_type):
    """
    Format metrics for display based on their type
    """
    if metric_type in ['productivity', 'quality', 'satisfaction']:
        return f"{value:.1f}%"
    elif metric_type == 'tasks_completed':
        return int(value)
    else:
        return value
